package eternal.future.tefmanager.model

import kotlinx.serialization.Serializable

/*******************************************************************************
 * TEFManager - CollectionItem
 * 模组合集的数据模型
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：模组合集的数据模型)
 *******************************************************************************/

@Serializable
data class CollectionModEntry(
    val pkgId: String = "",
    val name: String = "",
    val version: String = "",
    /** mod / module / plugin / modloader，对应包内 Manifest.json 的 type */
    val type: String = "",
    /** type == "mod" 时，属于哪个模组加载器的 pkgId */
    val loaderPkgId: String = "",
    /** 合集包里的原始文件名，仅用于展示 */
    val fileName: String = ""
)

@Serializable
data class CollectionItem(
    val pkgId: String = "",
    val name: String = "",
    val author: String = "",
    val version: String = "",
    val description: String = "",
    val installedAt: Long = 0L,
    val mods: List<CollectionModEntry> = emptyList()
)
