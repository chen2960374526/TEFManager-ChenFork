package eternal.future.tefmanager.ui.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ToggleOff
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import eternal.future.tefmanager.model.AddonUpdateInfo
import eternal.future.tefmanager.model.ModItem
import eternal.future.tefmanager.model.ModLoaderItem
import eternal.future.tefmanager.ui.dialogs.AddonUpdateDialog
import eternal.future.tefmanager.utils.NetworkService
import eternal.future.tefmanager.utils.addon.AddonManager
import eternal.future.tefmanager.utils.isVersionGreater
import eternal.future.tefmanager.strings.StringsResource.Strings
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/*******************************************************************************
 * TEFManager - ModListSection
 *
 * 本机已安装模组列表（原 ManagerScreen 内私有实现，抽出为公共组件）。
 * 现由「管理」页与「模组仓库」页共同复用。
 *******************************************************************************/

/**
 * 某个模组加载器下、本机已安装的模组列表。
 *
 * @param loader 目标加载器
 * @param query 过滤关键词（空 = 不过滤）
 */
@Composable
fun ModListSection(
    loader: ModLoaderItem,
    query: String = "",
    horizontalPadding: Dp = 16.dp,
    onRefresh: (() -> Unit)? = null,
    onAddMod: (() -> Unit)? = null
) {
    val networkService = remember { NetworkService() }
    // 模组列表用状态持有：进入页面时自动创建/加载管理器，无需手动点刷新
    var mods by remember(loader.pkgId) { mutableStateOf<List<ModItem>>(emptyList()) }
    var refreshTick by remember(loader.pkgId) { mutableStateOf(0) }
    val updates = remember { mutableStateMapOf<String, AddonUpdateInfo>() }
    var dialogFor by remember { mutableStateOf<Pair<ModItem, AddonUpdateInfo>?>(null) }

    // 首次进入 & 每次刷新：确保管理器已创建并从数据库重读列表
    LaunchedEffect(loader.pkgId, refreshTick) {
        val manager = AddonManager.getOrCreateModManager(loader.pkgId, autoCreate = true)
        manager?.refreshPacksList()
        mods = manager?.packs.orEmpty()
    }

    LaunchedEffect(mods.map { it.pkgId }) {
        updates.clear()
        mods.filter { it.updateInfoUrl.isNotBlank() }.forEach { mod ->
            launch {
                val info = networkService.getJson<AddonUpdateInfo>(mod.updateInfoUrl) ?: return@launch
                if (isVersionGreater(info.version, mod.version)) {
                    updates[mod.pkgId] = info
                }
            }
        }
    }

    val keyword = query.trim().lowercase()
    val shown = if (keyword.isEmpty()) mods else mods.filter { mod ->
        mod.name.lowercase().contains(keyword) ||
            mod.pkgId.lowercase().contains(keyword) ||
            mod.brieflyDescribe.lowercase().contains(keyword)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = horizontalPadding)
    ) {
        SectionHeader(
            title = loader.name,
            subtitle = loader.description,
            icon = Icons.Rounded.GridView
        )
        Spacer(modifier = Modifier.height(12.dp))
        SectionActionRow(
            primaryText = Strings.manager.mod.add,
            onPrimary = onAddMod ?: {},
            secondaryText = Strings.refresh,
            onSecondary = {
                refreshTick++
                onRefresh?.invoke()
            },
            showPrimary = onAddMod != null
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (shown.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.GridView,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (keyword.isEmpty()) Strings.manager.search.noResults else Strings.manager.search.noResults,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(shown, key = { it.pkgId }) { mod ->
                    val manager = AddonManager.getOrCreateModManager(loader.pkgId)
                    if (manager != null) {
                        var enabled by remember(mod.pkgId) {
                            mutableStateOf(manager.isEnabled(mod.pkgId))
                        }
                        ModItemCard(
                            mod = mod,
                            enabled = enabled,
                            customIconPath = manager.getIconFilePath(mod.pkgId),
                            settingsStore = manager.getSettingsStore(mod.pkgId),
                            hasUpdate = updates.containsKey(mod.pkgId),
                            onCheckUpdate = { updates[mod.pkgId]?.let { dialogFor = mod to it } },
                            onEnableChange = { enable ->
                                enabled = enable
                                if (enable) manager.enable(mod.pkgId)
                                else manager.disable(mod.pkgId)
                            },
                            onDelete = {
                                runBlocking {
                                    manager.delete(mod.pkgId)
                                }
                            }
                        )
                    }
                }
            }
        }

        dialogFor?.let { (mod, info) ->
            AddonUpdateDialog(
                title = mod.name,
                currentVersion = mod.version,
                updateInfo = info,
                installPackage = { path ->
                    runBlocking { AddonManager.install(path) }
                },
                onDismiss = { dialogFor = null }
            )
        }
    }
}

/**
 * 区块操作行：一排等宽按钮，固定在描述文字下方。
 *
 * @param primaryText 主按钮文案（左侧，「添加 XXX」）
 * @param onPrimary 主按钮点击
 * @param secondaryText 次按钮文案（右侧，「刷新」）；为 null 时不显示
 * @param onSecondary 次按钮点击
 * @param showPrimary 是否显示主按钮
 */
@Composable
fun SectionActionRow(
    primaryText: String,
    onPrimary: () -> Unit,
    secondaryText: String? = null,
    onSecondary: (() -> Unit)? = null,
    showPrimary: Boolean = true
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (showPrimary) {
            FilledTonalButton(
                onClick = onPrimary,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(primaryText, style = MaterialTheme.typography.labelLarge)
            }
        }
        if (secondaryText != null && onSecondary != null) {
            OutlinedButton(
                onClick = onSecondary,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(secondaryText, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/** 区块标题（图标 + 标题 + 副标题） */
@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    icon: ImageVector? = null,
    action: @Composable (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        icon?.let {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(36.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        action?.invoke()
    }
}

/** 加载器未启用时的占位提示 */
@Composable
fun DisabledLoaderSection(loader: ModLoaderItem?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.ToggleOff,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = Strings.manager.modloader.disabled,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = Strings.manager.modloader.disabledHint(loader?.name ?: ""),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}
