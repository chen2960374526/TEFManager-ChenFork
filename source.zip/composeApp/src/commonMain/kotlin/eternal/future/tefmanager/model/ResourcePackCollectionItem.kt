package eternal.future.tefmanager.model

import kotlinx.serialization.Serializable

/*******************************************************************************
 * TEFManager - ResourcePackCollectionItem
 * 资源包合集的数据模型
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：资源包合集的数据模型)
 *******************************************************************************/

@Serializable
data class ResourcePackCollectionEntry(
    /** 装好后的实际文件名，是各个 PackManager 里的唯一 key */
    val fileName: String = "",
    val name: String = "",
    val version: String = "",
    /** TexturePack / LanguagePack / LanguagePatchPack / AudioPack / FontPack */
    val packType: String = ""
)

@Serializable
data class ResourcePackCollectionItem(
    val pkgId: String = "",
    val name: String = "",
    val author: String = "",
    val version: String = "",
    val description: String = "",
    val installedAt: Long = 0L,
    val packs: List<ResourcePackCollectionEntry> = emptyList()
)