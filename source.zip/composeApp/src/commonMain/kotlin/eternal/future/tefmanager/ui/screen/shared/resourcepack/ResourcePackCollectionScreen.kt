package eternal.future.tefmanager.ui.screen.shared.resourcepack

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import eternal.future.tefmanager.Platform
import eternal.future.tefmanager.model.ResourcePackCollectionEntry
import eternal.future.tefmanager.model.ResourcePackCollectionItem
import eternal.future.tefmanager.ui.component.SectionActionRow
import eternal.future.tefmanager.utils.resourcepack.ResourcePackCollectionManager
import io.github.vinceglb.filekit.dialogs.FileKitMode
import io.github.vinceglb.filekit.dialogs.compose.rememberFilePickerLauncher
import io.github.vinceglb.filekit.name
import io.github.vinceglb.filekit.size
import io.github.vinceglb.filekit.source
import kotlinx.coroutines.launch
import kotlinx.io.buffered
import kotlinx.io.files.SystemFileSystem
import okio.FileSystem
import okio.SYSTEM

/*******************************************************************************
 * TEFManager - ResourcePackCollectionScreen
 * 资源包合集界面
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：资源包合集界面)
 *******************************************************************************/

object ResourcePackCollectionScreen : Screen {

    @Composable
    override fun Content() {
        var tick by remember { mutableStateOf(0) }
        var progress by remember { mutableStateOf("") }
        var installing by remember { mutableStateOf(false) }
        var pendingDelete by remember { mutableStateOf<ResourcePackCollectionItem?>(null) }
        var deleting by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        LaunchedEffect(Unit) { ResourcePackCollectionManager.load() }

        val picker = rememberFilePickerLauncher(mode = FileKitMode.Multiple(maxItems = 1)) { files ->
            val file = files?.firstOrNull()
            if (file != null) {
                scope.launch {
                    installing = true
                    progress = "正在拷贝合集包…"
                    val tmpDir = Platform.getDirectory("tmp") / "resource_collection_tmp"
                    try {
                        FileSystem.SYSTEM.deleteRecursively(tmpDir, mustExist = false)
                        FileSystem.SYSTEM.createDirectories(tmpDir)
                        val dest = tmpDir / file.name
                        SystemFileSystem.sink(kotlinx.io.files.Path(dest.toString())).buffered().use { sink ->
                            sink.write(file.source(), file.size())
                            sink.flush()
                        }
                        progress = "正在安装合集…"
                        val result = ResourcePackCollectionManager.installCollection(dest) { msg -> progress = msg }
                        if (result == null && progress.isBlank()) progress = "安装失败"
                        tick++
                    } catch (e: Throwable) {
                        progress = "安装失败：" + (e.message ?: e.javaClass.simpleName)
                    } finally {
                        installing = false
                        try {
                            FileSystem.SYSTEM.deleteRecursively(tmpDir, mustExist = false)
                        } catch (_: Throwable) {
                        }
                    }
                }
            }
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 4.dp)) {
            SectionActionRow(
                primaryText = if (installing) "安装中…" else "安装合集包",
                onPrimary = { if (!installing) picker.launch() },
                secondaryText = "刷新",
                onSecondary = {
                    ResourcePackCollectionManager.load()
                    tick++
                }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "合集包是一个 zip：里面直接放多个资源包（语言包 / 语言补丁包 / 材质包 / 字体包 / 音频包都行），也可以加 Collection.json 写合集名。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (progress.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    progress,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.height(10.dp))

            if (ResourcePackCollectionManager.collections.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Rounded.Inventory2,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "还没有资源包合集",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "点上面的「安装合集包」，选一个装好资源包的 zip",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(
                        items = ResourcePackCollectionManager.collections.toList(),
                        key = { it.pkgId }
                    ) { item ->
                        CollectionCard(
                            item = item,
                            tick = tick,
                            onChanged = { tick++ },
                            onRequestDelete = { pendingDelete = it }
                        )
                    }
                }
            }
        }
        pendingDelete?.let { target ->
            AlertDialog(
                onDismissRequest = { if (!deleting) pendingDelete = null },
                title = { Text("删除合集") },
                text = {
                    Text(
                        "将删除「${target.name}」以及里面的 ${target.packs.size} 个资源包" +
                                "（会从设备上一并移除，其他合集里如果也有同一个也会一起消失）。"
                    )
                },
                confirmButton = {
                    TextButton(
                        enabled = !deleting,
                        onClick = {
                            scope.launch {
                                deleting = true
                                progress = "正在删除合集…"
                                ResourcePackCollectionManager.deleteCollection(target) { msg -> progress = msg }
                                deleting = false
                                pendingDelete = null
                                tick++
                            }
                        }
                    ) {
                        Text("删除", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { if (!deleting) pendingDelete = null }, enabled = !deleting) {
                        Text("取消")
                    }
                }
            )
        }

    }

    @Composable
    private fun CollectionCard(
        item: ResourcePackCollectionItem,
        tick: Int,
        onChanged: () -> Unit,
        onRequestDelete: (ResourcePackCollectionItem) -> Unit
    ) {
        var expanded by remember(item.pkgId) { mutableStateOf(false) }

        var allOn by remember(item.pkgId) {
            mutableStateOf(ResourcePackCollectionManager.allEnabled(item))
        }
        var enabledCount by remember(item.pkgId) {
            mutableStateOf(ResourcePackCollectionManager.enabledCount(item))
        }
        var installedCount by remember(item.pkgId) {
            mutableStateOf(ResourcePackCollectionManager.installedCount(item))
        }

        LaunchedEffect(tick, item.pkgId) {
            allOn = ResourcePackCollectionManager.allEnabled(item)
            enabledCount = ResourcePackCollectionManager.enabledCount(item)
            installedCount = ResourcePackCollectionManager.installedCount(item)
        }

        val total = item.packs.size

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing))
                .padding(4.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (allOn) {
                    MaterialTheme.colorScheme.surfaceContainerHigh
                } else {
                    MaterialTheme.colorScheme.surfaceContainerLow
                }
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 0.dp,
                pressedElevation = 0.dp,
                focusedElevation = 0.dp,
                hoveredElevation = 0.dp
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (allOn) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHighest
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Inventory2,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = if (allOn) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium,
                            color = if (allOn) {
                                MaterialTheme.colorScheme.onSurface
                            } else {
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = buildString {
                                append("$total 个资源包")
                                if (item.version.isNotBlank()) append(" · v${item.version}")
                                append(" · 已开启 $enabledCount/$installedCount")
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (item.description.isNotBlank()) {
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline,
                                fontSize = 10.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Switch(
                        checked = allOn,
                        onCheckedChange = { on ->
                            allOn = on
                            ResourcePackCollectionManager.setAllEnabled(item, on)
                            enabledCount = ResourcePackCollectionManager.enabledCount(item)
                            installedCount = ResourcePackCollectionManager.installedCount(item)
                            onChanged()
                        }
                    )
                    IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                AnimatedVisibility(
                    visible = expanded,
                    enter = fadeIn(animationSpec = tween(200)) + expandVertically(
                        animationSpec = tween(200, easing = FastOutSlowInEasing)
                    ),
                    exit = fadeOut(animationSpec = tween(150)) + shrinkVertically(
                        animationSpec = tween(150, easing = FastOutSlowInEasing)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    ) {
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant,
                            thickness = 0.5.dp
                        )
                        Spacer(Modifier.height(4.dp))
                        item.packs.forEach { entry ->
                            PackRow(
                                entry = entry,
                                sharedAllOn = allOn,
                                onToggled = {
                                    allOn = ResourcePackCollectionManager.allEnabled(item)
                                    enabledCount = ResourcePackCollectionManager.enabledCount(item)
                                    installedCount = ResourcePackCollectionManager.installedCount(item)
                                    onChanged()
                                }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { onRequestDelete(item) }) {
                                Text("删除合集", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun PackRow(
        entry: ResourcePackCollectionEntry,
        sharedAllOn: Boolean,
        onToggled: () -> Unit
    ) {
        var installed by remember(entry.fileName) {
            mutableStateOf(ResourcePackCollectionManager.isInstalled(entry))
        }
        var enabled by remember(entry.fileName) {
            mutableStateOf(ResourcePackCollectionManager.isEnabled(entry))
        }

        LaunchedEffect(sharedAllOn, entry.fileName) {
            installed = ResourcePackCollectionManager.isInstalled(entry)
            enabled = ResourcePackCollectionManager.isEnabled(entry)
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = entry.name,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (enabled) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = buildString {
                        append(ResourcePackCollectionManager.typeLabel(entry.packType))
                        if (entry.version.isNotBlank()) append(" · v${entry.version}")
                        if (!installed) append(" · 未安装")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Switch(
                checked = enabled,
                enabled = installed,
                onCheckedChange = { on ->
                    enabled = on
                    ResourcePackCollectionManager.setEnabled(entry, on)
                    onToggled()
                }
            )
        }
    }
}