package eternal.future.tefmanager.ui.component

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import eternal.future.tefmanager.ConfigurationState
import eternal.future.tefmanager.utils.toFileUrlString
import io.kamel.image.KamelImage
import io.kamel.image.asyncPainterResource
import okio.Path.Companion.toPath

/*******************************************************************************
 * TEFManager - AppBackground
 *
 * 自定义背景层。铺满整个窗口，位于所有界面之下。
 * 上层的页面底色由 Theme 按 ConfigurationState.backgroundDim 透明度处理，
 * 因此这里只负责画图，不再叠加遮罩。
 *******************************************************************************/

/** 背景图铺满窗口；未设置背景或文件不可用时什么都不画。 */
@Composable
fun AppBackgroundLayer() {
    val path = ConfigurationState.customBackgroundPath
    if (path.isBlank()) return

    Box(modifier = Modifier.fillMaxSize()) {
        KamelImage(
            resource = { asyncPainterResource(data = path.toPath().toFileUrlString()) },
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}
