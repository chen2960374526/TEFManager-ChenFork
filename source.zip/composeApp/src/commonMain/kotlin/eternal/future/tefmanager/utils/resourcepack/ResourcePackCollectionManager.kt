package eternal.future.tefmanager.utils.resourcepack

import androidx.compose.runtime.mutableStateListOf
import eternal.future.tefmanager.Platform
import eternal.future.tefmanager.model.ResourcePackCollectionEntry
import eternal.future.tefmanager.model.ResourcePackCollectionItem
import eternal.future.tefmanager.model.ResourcesPackItem
import eternal.future.tefmanager.utils.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import no.synth.kmpzip.okio.ZipFile
import no.synth.kmpzip.okio.asSource
import okio.FileSystem
import okio.Path
import okio.SYSTEM
import okio.buffer
import okio.use
import kotlin.time.Clock

/*******************************************************************************
 * TEFManager - ResourcePackCollectionManager
 * 资源包合集（合集安装 / 一键开关）
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：资源包合集（合集安装 / 一键开关）)
 *******************************************************************************/

object ResourcePackCollectionManager {

    private val fileSystem = FileSystem.SYSTEM
    private val logger = AppLogger

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    val collections = mutableStateListOf<ResourcePackCollectionItem>()

    private val storeDir: Path get() = Platform.getData("resource_collections")
    private val storeFile: Path get() = storeDir / "collections.json"

    // ───────────────────────────── 持久化 ─────────────────────────────

    fun load() {
        try {
            if (!fileSystem.exists(storeFile)) {
                collections.clear()
                return
            }
            val text = fileSystem.source(storeFile).buffer().use { it.readUtf8() }
            val list = json.decodeFromString<List<ResourcePackCollectionItem>>(text)
            val seen = mutableSetOf<String>()
            var repaired = false
            val fixed = list.filter { it.pkgId.isNotBlank() }.map { item ->
                if (seen.add(item.pkgId)) {
                    item
                } else {
                    var newId = "rpcollection." + stableId(item.name + "_" + item.installedAt)
                    while (!seen.add(newId)) newId += "x"
                    repaired = true
                    item.copy(pkgId = newId)
                }
            }
            collections.clear()
            collections.addAll(fixed)
            if (repaired) save()
        } catch (e: Throwable) {
            logger.w("[ResourceCollection] load failed: ${e.message}")
        }
    }

    private fun save() {
        try {
            if (!fileSystem.exists(storeDir)) fileSystem.createDirectories(storeDir)
            fileSystem.sink(storeFile).buffer().use { sink ->
                sink.writeUtf8(json.encodeToString(collections.toList()))
                sink.flush()
            }
        } catch (e: Throwable) {
            logger.w("[ResourceCollection] save failed: ${e.message}")
        }
    }

    // ───────────────────────────── 安装 ─────────────────────────────

    suspend fun installCollection(
        zipPath: Path,
        onProgress: (String) -> Unit = {}
    ): ResourcePackCollectionItem? = withContext(Dispatchers.IO) {
        val tmpDir = Platform.getDirectory("tmp") / "resource_collection_install"
        try {
            fileSystem.deleteRecursively(tmpDir, mustExist = false)
            fileSystem.createDirectories(tmpDir)

            var metaName = zipPath.name.substringBeforeLast('.')
            var metaPkgId = ""
            var metaAuthor = ""
            var metaVersion = ""
            var metaDescription = ""

            val payloads = mutableListOf<Path>()

            onProgress("正在读取合集包…")
            ZipFile(fileSystem.openReadOnly(zipPath)).use { zip ->
                zip.entries.forEach { entry ->
                    if (entry.isDirectory) return@forEach
                    val lower = entry.name.lowercase()
                    if (entry.name == "Collection.json" || entry.name == "collection.json") {
                        try {
                            val raw = zip.getInputStream(entry).asSource().buffer().use { it.readUtf8() }
                            val obj = json.parseToJsonElement(raw).jsonObject
                            metaName = obj.str("name").ifBlank { metaName }
                            metaPkgId = obj.str("pkgId")
                            metaAuthor = obj.str("author")
                            metaVersion = obj.str("version")
                            metaDescription = obj.str("description")
                        } catch (e: Throwable) {
                                                        logger.w("[ResourceCollection] Collection.json parse failed: ${e.message}")
                        }
                        return@forEach
                    }
                    // 资源包本体
                    if (lower.endsWith(".zip")) {
                        val dest = tmpDir / entry.name.substringAfterLast('/')
                        fileSystem.sink(dest).buffer().use { sink ->
                            zip.getInputStream(entry).asSource().use { src -> sink.writeAll(src) }
                            sink.flush()
                        }
                        payloads.add(dest)
                    }
                }
            }

            if (payloads.isEmpty()) {
                onProgress("合集包里没有找到任何资源包")
                return@withContext null
            }

            val entries = mutableListOf<ResourcePackCollectionEntry>()
            val total = payloads.size
            payloads.forEachIndexed { index, pkg ->
                val pkgName = pkg.name.substringBeforeLast('.')
                onProgress("正在安装 ${index + 1}/$total：$pkgName")
                var installed: ResourcesPackItem? = null
                try {
                    installed = ResourcePackManager.installPack(pkg).getOrNull()
                } catch (e: Throwable) {
                    logger.e("[ResourceCollection] install failed: $pkgName", e)
                    onProgress("$pkgName 安装失败：${e.message ?: e.javaClass.simpleName}")
                }
                if (installed != null) {
                    entries.add(
                        ResourcePackCollectionEntry(
                            fileName = installed.fileName,
                            name = installed.name,
                            version = installed.version,
                            packType = installed.packType.name
                        )
                    )
                }
            }

            if (entries.isEmpty()) {
                onProgress("合集里的包都没能识别，安装中止")
                return@withContext null
            }

            val sameName = collections.firstOrNull { it.name == metaName }
            val resolvedId = when {
                sameName != null -> sameName.pkgId
                metaPkgId.isNotBlank() && collections.none { it.pkgId == metaPkgId } -> metaPkgId
                else -> "rpcollection." + stableId(metaName)
            }

            val item = ResourcePackCollectionItem(
                pkgId = resolvedId,
                name = metaName,
                author = metaAuthor,
                version = metaVersion,
                description = metaDescription,
                installedAt = Clock.System.now().toEpochMilliseconds(),
                packs = entries
            )

            collections.removeAll { it.pkgId == item.pkgId }
            collections.add(item)
            save()

            // 默认全部关闭
            onProgress("合集安装完成（默认关闭）")
            setAllEnabled(item, false)
            item
        } catch (e: Throwable) {
            logger.e("[ResourceCollection] installCollection failed", e)
            onProgress("安装失败：${e.message ?: e.javaClass.simpleName}")
            null
        } finally {
            try {
                fileSystem.deleteRecursively(tmpDir, mustExist = false)
            } catch (_: Throwable) {
            }
        }
    }

    // ───────────────────────────── 状态与开关 ─────────────────────────────

    private fun packsOf(type: String): List<ResourcesPackItem> = when (type) {
        "TexturePack" -> TexturePackManager.packs
        "LanguagePack" -> LanguagePackManager.languagePacks
        "LanguagePatchPack" -> LanguagePatchPackManager.packs
        "AudioPack" -> AudioManager.packs
        "FontPack" -> FontPackManager.fontPacks
        else -> emptyList()
    }

    fun isInstalled(entry: ResourcePackCollectionEntry): Boolean =
        packsOf(entry.packType).any { it.fileName == entry.fileName }

    fun isEnabled(entry: ResourcePackCollectionEntry): Boolean = try {
        when (entry.packType) {
            "TexturePack" -> TexturePackManager.isPackEnabled(entry.fileName)
            "LanguagePack" -> LanguagePackManager.isPackEnabled(entry.fileName)
            "LanguagePatchPack" -> LanguagePatchPackManager.isPackEnabled(entry.fileName)
            "AudioPack" -> AudioManager.isPackEnabled(entry.fileName)
            // 字体包是单选：选中即为启用
            "FontPack" -> FontPackManager.isFontPackSelected(entry.fileName)
            else -> false
        }
    } catch (e: Throwable) {
        logger.w("[ResourceCollection] isEnabled failed: ${entry.fileName}: ${e.message}")
        false
    }

    fun setEnabled(entry: ResourcePackCollectionEntry, enabled: Boolean): Boolean = try {
        when (entry.packType) {
            "TexturePack" -> {
                TexturePackManager.setPackEnabled(entry.fileName, enabled)
                true
            }
            "LanguagePack" -> LanguagePackManager.setPackEnabled(entry.fileName, enabled)
            "LanguagePatchPack" -> {
                LanguagePatchPackManager.setPackEnabled(entry.fileName, enabled)
                true
            }
            "AudioPack" -> {
                AudioManager.setPackEnabled(entry.fileName, enabled)
                true
            }
            "FontPack" -> {
                if (enabled) {
                    FontPackManager.selectFontPack(entry.fileName)
                } else if (FontPackManager.isFontPackSelected(entry.fileName)) {
                    FontPackManager.deselectFontPack()
                }
                true
            }
            else -> false
        }
    } catch (e: Throwable) {
        logger.w("[ResourceCollection] setEnabled failed: ${entry.fileName}: ${e.message}")
        false
    }

    fun installedCount(item: ResourcePackCollectionItem): Int = item.packs.count { isInstalled(it) }

    fun enabledCount(item: ResourcePackCollectionItem): Int =
        item.packs.count { isInstalled(it) && isEnabled(it) }

    fun allEnabled(item: ResourcePackCollectionItem): Boolean {
        val installed = item.packs.filter { isInstalled(it) }
        return installed.isNotEmpty() && installed.all { isEnabled(it) }
    }

    fun setAllEnabled(item: ResourcePackCollectionItem, enabled: Boolean): Int {
        var done = 0
        item.packs.forEach { entry ->
            if (!isInstalled(entry)) return@forEach
            if (setEnabled(entry, enabled)) done++
        }
        return done
    }

    fun remove(pkgId: String) {
        collections.removeAll { it.pkgId == pkgId }
        save()
    }

    /** 删除合集：把里面的资源包从设备删除，然后移除合集记录 */
    suspend fun deleteCollection(
        item: ResourcePackCollectionItem,
        onProgress: (String) -> Unit = {}
    ): Int = withContext(Dispatchers.IO) {
        // 先确保各资源包的列表都读过了。
        // 列表原先只有进过对应页面才会加载，没打开的类别会被判成「未安装」直接跳过，
        // 结果就是合集没了、文件还在。
        reloadAllPackLists()

        var done = 0
        var skipped = 0
        val total = item.packs.size
        val failed = mutableListOf<String>()

        item.packs.forEachIndexed { index, entry ->
            onProgress("正在删除 ${index + 1}/$total：${entry.name}")
            try {
                val target = resolvePack(entry)
                if (target == null) {
                    // 设备上已经找不到这个包了，当作已完成
                    skipped++
                } else if (deletePackByType(target.first, target.second)) {
                    done++
                } else {
                    failed += entry.name
                }
            } catch (e: Throwable) {
                logger.e("[ResourceCollection] delete failed: ${entry.fileName}", e)
                failed += entry.name
            }
        }

        // 删完重新读一遍，确认是不是真的没了
        reloadAllPackLists()
        val left = item.packs.count { isInstalled(it) }

        collections.removeAll { it.pkgId == item.pkgId }
        save()

        val removed = done + skipped
        onProgress(
            if (left == 0) {
                "已删除 $removed 项"
            } else {
                "已删除 $removed 项，仍有 $left 项没删掉" +
                        if (failed.isNotEmpty()) "（${failed.joinToString("、")}）" else ""
            }
        )
        removed
    }

    /** 把五类资源包的列表都重新读一遍 */
    private fun reloadAllPackLists() {
        runCatching { TexturePackManager.reload() }
        runCatching { LanguagePackManager.reload() }
        runCatching { LanguagePatchPackManager.reload() }
        runCatching { FontPackManager.reload() }
        runCatching { AudioManager.reload() }
    }

    /**
     * 找出这条记录在设备上对应哪个包：返回 (类型, 实际文件名)。
     * 先按存下来的文件名找；老数据里文件名可能对不上，再按显示名兜底；
     * 存的类型也可能不准，最后全类型扫一遍。
     */
    private fun resolvePack(entry: ResourcePackCollectionEntry): Pair<String, String>? {
        val types = listOf("TexturePack", "LanguagePack", "LanguagePatchPack", "AudioPack", "FontPack")

        // 1) 先在自己那一类里找
        packsOf(entry.packType).firstOrNull { it.fileName == entry.fileName }
            ?.let { return entry.packType to it.fileName }

        // 2) 按显示名在自己那一类里找
        packsOf(entry.packType).firstOrNull { entry.name.isNotBlank() && it.name == entry.name }
            ?.let { return entry.packType to it.fileName }

        // 3) 全类型扫，文件名优先，其次显示名
        types.forEach { type ->
            packsOf(type).firstOrNull { it.fileName == entry.fileName }
                ?.let { return type to it.fileName }
        }
        if (entry.name.isNotBlank()) {
            types.forEach { type ->
                packsOf(type).firstOrNull { it.name == entry.name }
                    ?.let { return type to it.fileName }
            }
        }
        return null
    }

    /** 按类型调用对应管理器的删除（材质包 / 音频包内部会连带删掉配对的那一份） */
    private suspend fun deletePackByType(type: String, fileName: String): Boolean = try {
        when (type) {
            "TexturePack" -> TexturePackManager.deletePack(fileName)
            "LanguagePack" -> LanguagePackManager.deleteLanguagePack(fileName)
            "LanguagePatchPack" -> LanguagePatchPackManager.deletePack(fileName)
            "AudioPack" -> AudioManager.deletePack(fileName)
            "FontPack" -> FontPackManager.deleteFontPack(fileName)
            else -> false
        }
    } catch (e: Throwable) {
        logger.e("[ResourceCollection] deletePackByType failed: $type/$fileName", e)
        false
    }

    /** 类型的中文名，用于界面显示 */
    fun typeLabel(type: String): String = when (type) {
        "TexturePack" -> "材质包"
        "LanguagePack" -> "语言包"
        "LanguagePatchPack" -> "语言补丁包"
        "AudioPack" -> "音频包"
        "FontPack" -> "字体包"
        else -> "未知类型"
    }

    private fun stableId(text: String): String {
        var hash = 1125899906842597L
        text.forEach { ch -> hash = hash * 31 + ch.code }
        return (hash and 0x7FFFFFFFFFFFFFFFL).toString(36)
    }

    private fun JsonObject.str(key: String): String = try {
        this[key]?.jsonPrimitive?.content ?: ""
    } catch (_: Throwable) {
        ""
    }
}