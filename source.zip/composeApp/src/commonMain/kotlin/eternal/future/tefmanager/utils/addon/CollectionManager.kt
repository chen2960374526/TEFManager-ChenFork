package eternal.future.tefmanager.utils.addon

import androidx.compose.runtime.mutableStateListOf
import eternal.future.tefmanager.Platform
import eternal.future.tefmanager.model.CollectionItem
import eternal.future.tefmanager.model.CollectionModEntry
import eternal.future.tefmanager.utils.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import no.synth.kmpzip.okio.ZipFile
import no.synth.kmpzip.okio.asSource
import okio.FileSystem
import okio.Path
import okio.SYSTEM
import okio.buffer
import okio.use
import kotlin.time.Clock

/*******************************************************************************
 * TEFManager - CollectionManager
 * 模组合集（合集安装 / 一键开关）
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：模组合集（合集安装 / 一键开关）)
 *******************************************************************************/

object CollectionManager {

    private val fileSystem = FileSystem.SYSTEM
    private val logger = AppLogger

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    /** 已安装的合集，供 UI 直接观察 */
    val collections = mutableStateListOf<CollectionItem>()

    private val storeDir: Path get() = Platform.getData("collections")
    private val storeFile: Path get() = storeDir / "collections.json"

    // ───────────────────────────── 持久化 ─────────────────────────────

    fun load() {
        try {
            if (!fileSystem.exists(storeFile)) {
                collections.clear()
                return
            }
            val text = fileSystem.source(storeFile).buffer().use { it.readUtf8() }
            val list = json.decodeFromString<List<CollectionItem>>(text)
            // 旧版本可能存下 pkgId 重复的记录（两个合集复制了同一份 Collection.json），
            // 这里顺手修掉，避免两张卡片的 key 撞车导致开关联动
            val seen = mutableSetOf<String>()
            var repaired = false
            val fixed = list.filter { it.pkgId.isNotBlank() }.map { item ->
                if (seen.add(item.pkgId)) {
                    item
                } else {
                    var newId = "collection." + stableId(item.name + "_" + item.installedAt)
                    while (!seen.add(newId)) newId += "x"
                    repaired = true
                    item.copy(pkgId = newId)
                }
            }
            collections.clear()
            collections.addAll(fixed)
            if (repaired) {
                logger.w("[Collection] 修复了重复的合集 pkgId")
                save()
            }
        } catch (e: Throwable) {
            logger.w("[Collection] load failed: ${e.message}")
        }
    }

    private fun save() {
        try {
            if (!fileSystem.exists(storeDir)) fileSystem.createDirectories(storeDir)
            fileSystem.sink(storeFile).buffer().use { sink ->
                sink.writeUtf8(json.encodeToString(collections.toList()))
                sink.flush()
            }
        } catch (e: Throwable) {
            logger.w("[Collection] save failed: ${e.message}")
        }
    }

    // ───────────────────────────── 安装 ─────────────────────────────

    /**
     * 安装一个合集包。
     * @param onProgress 进度文案回调（用于界面显示）
     * @return 安装完成后的合集记录；失败返回 null
     */
    suspend fun installCollection(
        zipPath: Path,
        onProgress: (String) -> Unit = {}
    ): CollectionItem? = withContext(Dispatchers.IO) {
        val tmpDir = Platform.getDirectory("tmp") / "collection_install"
        try {
            fileSystem.deleteRecursively(tmpDir, mustExist = false)
            fileSystem.createDirectories(tmpDir)

            var metaName = zipPath.name.substringBeforeLast('.')
            var metaPkgId = ""
            var metaAuthor = ""
            var metaVersion = ""
            var metaDescription = ""

            val payloads = mutableListOf<Path>()

            onProgress("正在读取合集包…")
            ZipFile(fileSystem.openReadOnly(zipPath)).use { zip ->
                zip.entries.forEach { entry ->
                    if (entry.isDirectory) return@forEach
                    val lower = entry.name.lowercase()
                    // 合集自身的说明文件
                    if (entry.name == "Collection.json" || entry.name == "collection.json") {
                        try {
                            val raw = zip.getInputStream(entry).asSource().buffer().use { it.readUtf8() }
                            val obj = json.parseToJsonElement(raw).jsonObject
                            metaName = obj.str("name").ifBlank { metaName }
                            metaPkgId = obj.str("pkgId")
                            metaAuthor = obj.str("author")
                            metaVersion = obj.str("version")
                            metaDescription = obj.str("description")
                        } catch (e: Throwable) {
                            logger.w("[Collection] Collection.json parse failed: ${e.message}")
                        }
                        return@forEach
                    }
                    // 模组安装包
                    if (lower.endsWith(".zip") || lower.endsWith(".tefpkg")) {
                        val dest = tmpDir / entry.name.substringAfterLast('/')
                        fileSystem.sink(dest).buffer().use { sink ->
                            zip.getInputStream(entry).asSource().use { src -> sink.writeAll(src) }
                            sink.flush()
                        }
                        payloads.add(dest)
                    }
                }
            }

            if (payloads.isEmpty()) {
                logger.w("[Collection] no package found in $zipPath")
                onProgress("合集包里没有找到任何模组安装包")
                return@withContext null
            }

            val entries = mutableListOf<CollectionModEntry>()
            val total = payloads.size
            payloads.forEachIndexed { index, pkg ->
                val pkgName = pkg.name.substringBeforeLast('.')
                onProgress("正在安装 ${index + 1}/$total：$pkgName")
                val meta = readPkgMeta(pkg)
                try {
                    AddonManager.install(pkg)
                } catch (e: Throwable) {
                    logger.e("[Collection] install failed: $pkgName", e)
                    onProgress("$pkgName 安装失败：${e.message ?: e.javaClass.simpleName}")
                }
                if (meta != null) entries.add(meta)
            }

            if (entries.isEmpty()) {
                onProgress("合集块内的包都没能识别，安装中止")
                return@withContext null
            }

            // 记录归属规则：
            // ① 名字相同 → 更新原来那条（重新装同一个合集）
            // ② 名字不同 → 一律当成新合集，即使两个包里的 Collection.json 写了同一个 pkgId
            //    （复制别人的 Collection.json 是最常见的情况，不能因为 pkgId 撞了就互相覆盖）
            val sameName = collections.firstOrNull { it.name == metaName }
            val resolvedId = when {
                sameName != null -> sameName.pkgId
                metaPkgId.isNotBlank() && collections.none { it.pkgId == metaPkgId } -> metaPkgId
                else -> "collection." + stableId(metaName)
            }

            val item = CollectionItem(
                pkgId = resolvedId,
                name = metaName,
                author = metaAuthor,
                version = metaVersion,
                description = metaDescription,
                installedAt = Clock.System.now().toEpochMilliseconds(),
                mods = entries
            )

            // 同一 pkgId 覆盖旧的记录
            collections.removeAll { it.pkgId == item.pkgId }
            collections.add(item)
            save()

            // 装完默认全部关闭，由用户自己决定开哪个合集
            onProgress("合集安装完成（默认关闭）")
            setAllEnabled(item, false)

            AddonManager.refreshModManager(ModLoaderManager.packs)
            onProgress("")
            item
        } catch (e: Throwable) {
            logger.e("[Collection] installCollection failed", e)
            onProgress("安装失败：${e.message ?: e.javaClass.simpleName}")
            null
        } finally {
            try {
                fileSystem.deleteRecursively(tmpDir, mustExist = false)
            } catch (_: Throwable) {
            }
        }
    }

    /** 从单个模组安装包里读出 pkgId / 名称 / 版本 / 类型 / 所属加载器 */
    private fun readPkgMeta(pkgPath: Path): CollectionModEntry? {
        return try {
            ZipFile(fileSystem.openReadOnly(pkgPath)).use { zip ->
                val infoEntry = zip.getEntry("Info.json") ?: return null
                val manifestEntry = zip.getEntry("Manifest.json")

                val infoText = zip.getInputStream(infoEntry).asSource().buffer().use { it.readUtf8() }
                val info = json.parseToJsonElement(infoText).jsonObject

                var type = ""
                var loaderPkgId = ""
                if (manifestEntry != null) {
                    val manifestText = zip.getInputStream(manifestEntry).asSource().buffer().use { it.readUtf8() }
                    val manifest = json.parseToJsonElement(manifestText).jsonObject
                    type = manifest.str("type").lowercase()
                    loaderPkgId = manifest.str("parentLoader")
                }

                val pkgId = info.str("pkgId")
                if (pkgId.isBlank()) return null

                CollectionModEntry(
                    pkgId = pkgId,
                    name = info.str("name").ifBlank { pkgId },
                    version = info.str("version"),
                    type = type,
                    loaderPkgId = loaderPkgId,
                    fileName = pkgPath.name
                )
            }
        } catch (e: Throwable) {
            logger.w("[Collection] read meta failed: ${pkgPath.name}: ${e.message}")
            null
        }
    }

    // ───────────────────────────── 状态与开关 ─────────────────────────────

    private fun modManager(loaderPkgId: String): ModManager? {
        if (loaderPkgId.isBlank()) return null
        return AddonManager.getOrCreateModManager(loaderPkgId, autoCreate = true)
    }

    fun isInstalled(entry: CollectionModEntry): Boolean = when (entry.type) {
        "mod" -> modManager(entry.loaderPkgId)?.getPackItem(entry.pkgId) != null
        "module" -> ModuleManager.getPackItem(entry.pkgId) != null
        "plugin" -> PluginManager.getPackItem(entry.pkgId) != null
        "modloader" -> ModLoaderManager.getPackItem(entry.pkgId) != null
        else -> false
    }

    fun isEnabled(entry: CollectionModEntry): Boolean = try {
        when (entry.type) {
            "mod" -> ModLoaderManager.isEnabled(entry.loaderPkgId) &&
                    (modManager(entry.loaderPkgId)?.isEnabled(entry.pkgId) == true)
            "module" -> ModuleManager.isEnabled(entry.pkgId)
            "plugin" -> PluginManager.isEnabled(entry.pkgId)
            "modloader" -> ModLoaderManager.isEnabled(entry.pkgId)
            else -> false
        }
    } catch (e: Throwable) {
        logger.w("[Collection] isEnabled failed: ${entry.pkgId}: ${e.message}")
        false
    }

    fun setEnabled(entry: CollectionModEntry, enabled: Boolean): Boolean = try {
        when (entry.type) {
            "mod" -> {
                // 开启模组时顺手把它的加载器也开上，否则内核不会去读这个加载器
                if (enabled && entry.loaderPkgId.isNotBlank()) ModLoaderManager.enable(entry.loaderPkgId)
                val manager = modManager(entry.loaderPkgId)
                if (manager == null) false
                else if (enabled) manager.enable(entry.pkgId) else manager.disable(entry.pkgId)
            }
            "module" -> if (enabled) ModuleManager.enable(entry.pkgId) else ModuleManager.disable(entry.pkgId)
            "plugin" -> if (enabled) PluginManager.enable(entry.pkgId) else PluginManager.disable(entry.pkgId)
            "modloader" -> if (enabled) ModLoaderManager.enable(entry.pkgId) else ModLoaderManager.disable(entry.pkgId)
            else -> false
        }
    } catch (e: Throwable) {
        logger.w("[Collection] setEnabled failed: ${entry.pkgId}: ${e.message}")
        false
    }

    /** 合集内已安装的条目数 */
    fun installedCount(item: CollectionItem): Int = item.mods.count { isInstalled(it) }

    /** 合集内已开启的条目数 */
    fun enabledCount(item: CollectionItem): Int = item.mods.count { isInstalled(it) && isEnabled(it) }

    /** 是否全部已开启（用于总开关状态） */
    fun allEnabled(item: CollectionItem): Boolean {
        val installed = item.mods.filter { isInstalled(it) }
        return installed.isNotEmpty() && installed.all { isEnabled(it) }
    }

    /** 一键全开 / 全关，返回成功操作的条目数 */
    fun setAllEnabled(item: CollectionItem, enabled: Boolean): Int {
        var done = 0
        item.mods.forEach { entry ->
            if (!isInstalled(entry)) return@forEach
            if (setEnabled(entry, enabled)) done++
        }
        return done
    }

    /** 只从合集列表移除（不卸载内容） */
    fun remove(pkgId: String) {
        collections.removeAll { it.pkgId == pkgId }
        save()
    }

    /**
     * 删除合集：把合集里的模组 / 模组加载器 / 模块 / 插件一并从设备删除，然后移除这条合集记录。
     * @return 成功删除的条目数
     */
    suspend fun deleteCollection(
        item: CollectionItem,
        onProgress: (String) -> Unit = {}
    ): Int = withContext(Dispatchers.IO) {
        var done = 0
        val total = item.mods.size
        item.mods.forEachIndexed { index, entry ->
            if (!isInstalled(entry)) return@forEachIndexed
            onProgress("正在删除 ${index + 1}/$total：${entry.name}")
            try {
                val ok = when (entry.type) {
                    "mod" -> {
                        val manager = modManager(entry.loaderPkgId)
                        manager != null && manager.delete(entry.pkgId)
                    }
                    "module" -> ModuleManager.delete(entry.pkgId)
                    "plugin" -> PluginManager.delete(entry.pkgId)
                    "modloader" -> ModLoaderManager.delete(entry.pkgId)
                    else -> false
                }
                if (ok) done++
            } catch (e: Throwable) {
                logger.e("[Collection] delete failed: ${entry.pkgId}", e)
            }
        }

        collections.removeAll { it.pkgId == item.pkgId }
        save()
        try {
            AddonManager.refreshModManager(ModLoaderManager.packs)
        } catch (_: Throwable) {
        }
        onProgress("已删除 $done 项")
        done
    }

    /** 加载器名称，找不到就返回 pkgId */
    fun loaderName(loaderPkgId: String): String {
        if (loaderPkgId.isBlank()) return ""
        return ModLoaderManager.packs.firstOrNull { it.pkgId == loaderPkgId }?.name ?: loaderPkgId
    }

    private fun stableId(text: String): String {
        var hash = 1125899906842597L
        text.forEach { ch -> hash = hash * 31 + ch.code }
        return (hash and 0x7FFFFFFFFFFFFFFFL).toString(36)
    }

    private fun JsonObject.str(key: String): String = try {
        this[key]?.jsonPrimitive?.content ?: ""
    } catch (_: Throwable) {
        ""
    }
}