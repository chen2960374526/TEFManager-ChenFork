package eternal.future.tefmanager.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import eternal.future.tefmanager.utils.DataExporter
import eternal.future.tefmanager.utils.ExportEntry
import eternal.future.tefmanager.utils.ExportResult
import io.github.vinceglb.filekit.dialogs.compose.rememberDirectoryPickerLauncher
import io.github.vinceglb.filekit.name
import io.github.vinceglb.filekit.path
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*******************************************************************************
 * TEFManager - ExportDialog（导出数据）
 * 勾选条目后，每个条目导出一个独立的安装包，可再次导入
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：逐项导出安装包)
 *******************************************************************************/

@Composable
fun ExportDialog(onDismiss: () -> Unit) {
    // 条目里包含资源包列表，读取要碰磁盘，放到后台线程去，顺便给个加载态
    var entries by remember { mutableStateOf<List<ExportEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        entries = withContext(Dispatchers.IO) { DataExporter.listEntries() }
        loading = false
    }
    val grouped = remember(entries) { entries.groupBy { it.group } }
    val selected = remember { mutableStateMapOf<String, Boolean>() }
    val scope = rememberCoroutineScope()

    var exporting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ExportResult?>(null) }

    var targetUri by remember { mutableStateOf<String?>(null) }
    var targetName by remember { mutableStateOf(DataExporter.defaultTargetName()) }

    val dirPicker = rememberDirectoryPickerLauncher { dir ->
        if (dir != null) {
            targetUri = dir.path
            targetName = dir.name.ifBlank { dir.path }
        }
    }

    val selectedCount = selected.count { it.value }

    Dialog(onDismissRequest = { if (!exporting) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "导出数据",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "每个勾选的条目都会导出成一个独立安装包（和导入时的压缩包结构一致，可以再次导入）",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "导出到：",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        targetName,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    TextButton(onClick = { dirPicker.launch() }, enabled = !exporting) {
                        Text("选择目录")
                    }
                }

                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { entries.forEach { selected[it.id] = true } },
                        enabled = !exporting
                    ) { Text("全选") }
                    TextButton(
                        onClick = { selected.clear() },
                        enabled = !exporting
                    ) { Text("清空") }
                    Spacer(Modifier.weight(1f))
                    Text(
                        "已选 $selectedCount / ${entries.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                if (loading) {
                    Column(
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "正在读取内容…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else if (entries.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "没有可导出的内容",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        grouped.forEach { (group, list) ->
                            item(key = "g:$group") {
                                val allOn = list.all { selected[it.id] == true }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !exporting) {
                                            if (allOn) list.forEach { selected[it.id] = false }
                                            else list.forEach { selected[it.id] = true }
                                        }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = allOn,
                                        onCheckedChange = { on -> list.forEach { selected[it.id] = on } },
                                        enabled = !exporting
                                    )
                                    Text(
                                        group,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "(${list.size})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            items(list, key = { it.id }) { entry: ExportEntry ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !exporting) {
                                            selected[entry.id] = selected[entry.id] != true
                                        }
                                        .padding(start = 16.dp, top = 2.dp, bottom = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = selected[entry.id] == true,
                                        onCheckedChange = { on -> selected[entry.id] = on },
                                        enabled = !exporting
                                    )
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            entry.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (entry.detail.isNotBlank()) {
                                            Text(
                                                entry.detail,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (status.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (exporting) {
                            CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(
                            status,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                result?.let { r ->
                    val ok = r.files.size
                    val msg = buildString {
                        append("已导出 $ok 个安装包 → ${r.exportDir}")
                        if (r.failed.isNotEmpty()) append("，${r.failed.size} 项失败")
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    r.files.take(3).forEach { f ->
                        Text(
                            "· ${f.name}（${formatSize(f.sizeBytes)}）",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (r.files.size > 3) {
                        Text(
                            "· …共 ${r.files.size} 个",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                    r.failed.take(3).forEach { f ->
                        Text(
                            "× $f",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, enabled = !exporting) { Text("关闭") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val ids = selected.filter { it.value }.keys.toSet()
                            if (ids.isEmpty()) {
                                status = "请先勾选要导出的内容"
                                return@Button
                            }
                            scope.launch {
                                exporting = true
                                status = "准备中…"
                                result = try {
                                    DataExporter.export(ids, targetUri) { msg -> status = msg }
                                } catch (e: Throwable) {
                                    status = "导出失败：${e.message ?: e.javaClass.simpleName}"
                                    null
                                }
                                exporting = false
                                if (result != null) status = "导出完成"
                            }
                        },
                        enabled = !exporting && !loading,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (exporting) "导出中…" else "导出")
                    }
                }
            }
        }
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    return if (kb < 1024.0) {
        val v = (kb * 10).toLong() / 10.0
        "$v KB"
    } else {
        val v = (kb / 1024.0 * 10).toLong() / 10.0
        "$v MB"
    }
}