package eternal.future.tefmanager.model

import kotlinx.serialization.Serializable

/*******************************************************************************
 * TEFManager - UpdateInfo
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * GitHub: https://github.com/eternalfuture-e38299
 * Created: 2026/2/15
 *******************************************************************************/

@Serializable
data class UpdateInfo(
    val tefmanager: Info?,
    val tefkernel: Info?,
    val tefloader: Info?,
    // 添加其他模块
    val language: Info? = null,
    val texture: Info? = null,
    val font: Info? = null,
    val music: Info? = null
) {
    @Serializable
    data class Info(
        val fileName: String,
        val moduleName: String,
        val newVersion: String,
        val description: String,
        val downloadUrl: String,
        val externalUrl: String,
        val fileSize: String
    )
}