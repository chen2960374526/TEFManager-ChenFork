package eternal.future.tefmanager.utils

/*******************************************************************************
 * TEFManager - DataExporter（导出数据）
 * 每个模组 / 资源包导出成独立的安装包，和当初导入的包一致，可再次安装
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：逐项导出安装包)
 *******************************************************************************/

/**
 * 一个可导出的条目（一个模组 / 一个资源包 / 一个加载器 …）
 */
data class ExportEntry(
    val id: String = "",
    val group: String = "",
    val name: String = "",
    val detail: String = ""
)

/** 导出的一个文件 */
data class ExportedFile(
    val name: String = "",
    val path: String = "",
    val sizeBytes: Long = 0L
)

/** 导出结果 */
data class ExportResult(
    /** 实际输出目录（用户选的目录或默认目录） */
    val exportDir: String = "",
    val files: List<ExportedFile> = emptyList(),
    /** 失败条目说明 */
    val failed: List<String> = emptyList()
) {
    val totalSize: Long get() = files.sumOf { it.sizeBytes }
}

expect object DataExporter {
    /** 列出所有可以导出的条目 */
    fun listEntries(): List<ExportEntry>

    /**
     * 逐条导出成独立安装包。
     * @param selectedIds 选中的条目
     * @param targetUri 用户选择的目录（SAF uri 字符串），null = 默认 Download/TEFManager导出_时间
     */
    suspend fun export(
        selectedIds: Set<String>,
        targetUri: String? = null,
        onProgress: (String) -> Unit = {}
    ): ExportResult?

    /** 默认导出目录的展示名（未选目录时使用） */
    fun defaultTargetName(): String
}