package eternal.future.tefmanager.utils

import eternal.future.tefmanager.ConfigurationState
import eternal.future.tefmanager.MainActivity
import eternal.future.tefmanager.Platform
import eternal.future.tefmanager.utils.addon.AddonManager
import eternal.future.tefmanager.utils.addon.ModLoaderManager
import eternal.future.tefmanager.utils.addon.ModuleManager
import eternal.future.tefmanager.utils.addon.PluginManager
import eternal.future.tefmanager.utils.resourcepack.AudioManager
import eternal.future.tefmanager.utils.resourcepack.FontPackManager
import eternal.future.tefmanager.utils.resourcepack.LanguagePackManager
import eternal.future.tefmanager.utils.resourcepack.LanguagePatchPackManager
import eternal.future.tefmanager.utils.resourcepack.TexturePackManager
import kotlinx.datetime.TimeZone
import kotlinx.datetime.number
import kotlinx.datetime.toLocalDateTime
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLDecoder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.time.Clock

/*******************************************************************************
 * TEFManager - DataExporter (Android)
 * 每个条目导出成一个独立安装包（zip），结构和当初导入的一致，可以再次安装
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：逐项导出安装包)
 *******************************************************************************/

actual object DataExporter {

    private const val TAG_MOD = "mod:"
    private const val TAG_LOADER = "modloader:"
    private const val TAG_MODULE = "module:"
    private const val TAG_PLUGIN = "plugin:"
    private const val TAG_PACK = "pack:"
    private const val TAG_KERNEL = "kernel:"

    private val json = Json {
        prettyPrint = true
        encodeDefaults = true
    }

    // ───────────────────────── 列条目 ─────────────────────────

    actual fun listEntries(): List<ExportEntry> {
        val out = mutableListOf<ExportEntry>()

        // 内核（TEFKernel）：装在内核目录里的一堆 .so，把它重新打成一个可安装的 zip
        runCatching {
            val version = ConfigurationState.kernelVersion.ifBlank { "unknown" }
            out += ExportEntry(
                id = "$TAG_KERNEL$version",
                group = "内核",
                name = "TEFKernel",
                detail = "v$version"
            )
        }
        runCatching {
            ModLoaderManager.packs.forEach { loader ->
                out += ExportEntry(
                    id = "$TAG_LOADER${loader.pkgId}",
                    group = "模组加载器",
                    name = loader.name.ifBlank { loader.pkgId },
                    detail = if (loader.version.isBlank()) loader.pkgId else "v${loader.version}"
                )
            }
        }
        runCatching {
            ModuleManager.packs.forEach { m ->
                out += ExportEntry(
                    id = "$TAG_MODULE${m.pkgId}",
                    group = "内置模块",
                    name = m.name.ifBlank { m.pkgId },
                    detail = if (m.version.isBlank()) m.pkgId else "v${m.version}"
                )
            }
        }
        runCatching {
            PluginManager.packs.forEach { p ->
                out += ExportEntry(
                    id = "$TAG_PLUGIN${p.pkgId}",
                    group = "插件",
                    name = p.name.ifBlank { p.pkgId },
                    detail = if (p.version.isBlank()) p.pkgId else "v${p.version}"
                )
            }
        }
        runCatching {
            ModLoaderManager.packs.forEach { loader ->
                runCatching {
                    val manager = AddonManager.getOrCreateModManager(loader.pkgId) ?: return@runCatching
                    manager.packs.forEach { mod ->
                        out += ExportEntry(
                            id = "$TAG_MOD${loader.pkgId}:${mod.pkgId}",
                            group = "模组 · ${loader.name.ifBlank { loader.pkgId }}",
                            name = mod.name.ifBlank { mod.pkgId },
                            detail = if (mod.version.isBlank()) mod.pkgId else "v${mod.version}"
                        )
                    }
                }
            }
        }
        // 资源包列表原先只有进过对应页面才会加载，这里先主动读一遍，
        // 否则没打开过资源包页的时候导出对话框里什么都看不到
        runCatching { TexturePackManager.reload() }
        runCatching { LanguagePackManager.reload() }
        runCatching { LanguagePatchPackManager.reload() }
        runCatching { FontPackManager.reload() }
        runCatching { AudioManager.reload() }

        runCatching {
            TexturePackManager.packs.forEach {
                out += ExportEntry("${TAG_PACK}TexturePack:${it.fileName}", "材质包", it.name.ifBlank { it.fileName }, "v${it.version}")
            }
        }
        runCatching {
            LanguagePackManager.languagePacks.forEach {
                out += ExportEntry("${TAG_PACK}LanguagePack:${it.fileName}", "语言包", it.name.ifBlank { it.fileName }, "v${it.version}")
            }
        }
        runCatching {
            LanguagePatchPackManager.packs.forEach {
                out += ExportEntry("${TAG_PACK}LanguagePatchPack:${it.fileName}", "语言补丁包", it.name.ifBlank { it.fileName }, "v${it.version}")
            }
        }
        runCatching {
            FontPackManager.fontPacks.forEach {
                out += ExportEntry("${TAG_PACK}FontPack:${it.fileName}", "字体包", it.name.ifBlank { it.fileName }, "v${it.version}")
            }
        }
        runCatching {
            AudioManager.packs.forEach {
                out += ExportEntry("${TAG_PACK}AudioPack:${it.fileName}", "音频包", it.name.ifBlank { it.fileName }, "v${it.version}")
            }
        }

        return out
    }

    actual fun defaultTargetName(): String = "Download/TEFManager导出_${timestamp()}"

    // ───────────────────────── 导出 ─────────────────────────

    actual suspend fun export(
        selectedIds: Set<String>,
        targetUri: String?,
        onProgress: (String) -> Unit
    ): ExportResult? {
        if (selectedIds.isEmpty()) {
            onProgress("没有选中任何内容")
            return null
        }

        val root = File(Platform.getData(null).toString())

        // 1) 决定输出目录
        val stamp = timestamp()
        val realTargetDir: File = run {
            val fromUri = resolveRealPath(targetUri)
            if (fromUri != null) {
                File(fromUri)
            } else {
                File("/storage/emulated/0/Download/TEFManager导出_$stamp")
            }
        }
        // 先在应用目录里组装，最后再复制出去（避免权限问题）
        val workDir = File(root, "export/tmp_$stamp")
        workDir.mkdirs()

        val exported = mutableListOf<ExportedFile>()
        val failed = mutableListOf<String>()
        val total = selectedIds.size
        var index = 0

        selectedIds.forEach { id ->
            index++
            try {
                onProgress("正在导出 $index/$total…")
                val result = when {
                    id.startsWith(TAG_KERNEL) -> exportKernel(workDir)
                    id.startsWith(TAG_LOADER) -> exportAddonFile(root, workDir, id.removePrefix(TAG_LOADER), "modloader", "ModLoader")
                    id.startsWith(TAG_MODULE) -> exportAddonFile(root, workDir, id.removePrefix(TAG_MODULE), "module", "Module")
                    id.startsWith(TAG_PLUGIN) -> exportAddonFile(root, workDir, id.removePrefix(TAG_PLUGIN), "plugin", "Plugin")
                    id.startsWith(TAG_MOD) -> {
                        val rest = id.removePrefix(TAG_MOD)
                        exportMod(root, workDir, rest.substringBefore(':'), rest.substringAfter(':'))
                    }
                    id.startsWith(TAG_PACK) -> {
                        val rest = id.removePrefix(TAG_PACK)
                        exportResourcePack(root, workDir, rest.substringBefore(':'), rest.substringAfter(':'))
                    }
                    else -> null
                }
                if (result != null && result.isFile && result.length() > 0) {
                    exported += ExportedFile(result.name, result.absolutePath, result.length())
                } else {
                    failed += id
                }
            } catch (e: Throwable) {
                AppLogger.e("export item failed: $id", e)
                failed += id
            }
        }

        if (exported.isEmpty()) {
            onProgress("没有任何内容导出成功")
            return null
        }

        // 2) 写入目标目录
        //    用户自己选的目录走 SAF 授权写入（DocumentsContract），
        //    直接拿路径去写会被 scoped storage 拦掉，出现「一部分成功一部分失败」。
        var written = 0
        if (!targetUri.isNullOrBlank()) {
            onProgress("正在写入所选目录…")
            exported.forEach { f ->
                if (writeIntoSaf(targetUri, File(f.path))) {
                    written++
                } else {
                    failed += "${f.name}：写入所选目录失败"
                }
            }
        } else {
            onProgress("正在写入 ${realTargetDir.absolutePath} …")
            realTargetDir.mkdirs()
            exported.forEach { f ->
                if (copyOut(File(f.path), realTargetDir)) {
                    written++
                } else {
                    failed += "${f.name}：写入失败"
                }
            }
        }

        val targetDesc = if (!targetUri.isNullOrBlank()) "所选目录" else realTargetDir.absolutePath
        val desc = if (written == exported.size) {
            targetDesc
        } else {
            "$targetDesc（${exported.size - written} 个文件写入失败）"
        }

        try {
            workDir.deleteRecursively()
        } catch (_: Throwable) {
        }

        onProgress("完成：${exported.size} 个安装包")
        return ExportResult(exportDir = desc, files = exported, failed = failed)
    }

    // ───────────────────────── 单条导出 ─────────────────────────

    /** 模块 / 插件 / 加载器：pkg 里的 tefpkg 本体 + Manifest + Info */
    private fun exportAddonFile(
        root: File,
        outDir: File,
        pkgId: String,
        typeDir: String,
        manifestType: String
    ): File? {
        val body = File(root, "$typeDir/pkg/$pkgId.tefpkg")
        if (!body.isFile) return null

        var name = pkgId
        var version = ""
        var infoJson = ""
        when (manifestType) {
            "Module" -> {
                val item = ModuleManager.getPackItem(pkgId)
                if (item != null) {
                    name = item.name.ifBlank { pkgId }
                    version = item.version
                    infoJson = ModuleManager.toJsonString(item).orEmpty()
                }
            }
            "Plugin" -> {
                val item = PluginManager.getPackItem(pkgId)
                if (item != null) {
                    name = item.name.ifBlank { pkgId }
                    version = item.version
                    infoJson = PluginManager.toJsonString(item).orEmpty()
                }
            }
            else -> {
                val item = ModLoaderManager.getPackItem(pkgId)
                if (item != null) {
                    name = item.name.ifBlank { pkgId }
                    version = item.version
                    infoJson = ModLoaderManager.toJsonString(item).orEmpty()
                }
            }
        }
        if (infoJson.isBlank()) {
            infoJson = """{"pkgId":"$pkgId","name":"$name","version":"$version"}"""
        }

        val manifest = buildJsonObject {
            put("type", JsonPrimitive(manifestType))
            put("file", JsonPrimitive("$pkgId.tefpkg"))
            put("iconFile", JsonPrimitive("icon.png"))
        }

        val target = uniqueFile(outDir, displayFileName(name, version, pkgId))
        ZipOutputStream(FileOutputStream(target)).use { zos ->
            writeText(zos, "Info.json", infoJson)
            writeText(zos, "Manifest.json", manifest.toString())
            writeFile(zos, body, "$pkgId.tefpkg")
            addIcon(zos, root, typeDir, pkgId)
        }
        return target
    }

    /** 模组：本体 + 资源 + Manifest/Info，打包成和导入时一样结构的安装包 */
    private fun exportMod(root: File, outDir: File, loader: String, pkgId: String): File? {
        val loaderDir = File(root, "mods/$loader")
        val body = File(loaderDir, "mod/$pkgId")
        if (!body.isFile) return null

        val manager = AddonManager.getOrCreateModManager(loader)
        val item = manager?.getPackItem(pkgId)
        val name = item?.name?.ifBlank { pkgId } ?: pkgId
        val version = item?.version ?: ""
        val infoJson = item?.let { manager?.toJsonString(it) }.orEmpty()
            .ifBlank { """{"pkgId":"$pkgId","name":"$name","version":"$version"}""" }

        val resourcesDir = File(loaderDir, "private/$pkgId")
        val hasResources = resourcesDir.isDirectory && (resourcesDir.listFiles()?.isNotEmpty() == true)

        val manifest = buildJsonObject {
            put("type", JsonPrimitive("Mod"))
            put("file", JsonPrimitive("$pkgId.tefpkg"))
            put("parentLoader", JsonPrimitive(loader))
            if (hasResources) put("resources", JsonPrimitive("Resources"))
            put("iconFile", JsonPrimitive("icon.png"))
        }

        val target = uniqueFile(outDir, displayFileName(name, version, pkgId))
        ZipOutputStream(FileOutputStream(target)).use { zos ->
            writeText(zos, "Info.json", infoJson)
            writeText(zos, "Manifest.json", manifest.toString())
            writeFile(zos, body, "$pkgId.tefpkg")
            if (hasResources) addDirectory(zos, resourcesDir, "Resources/")
            addIcon(zos, root, "mods/$loader", pkgId)
        }
        return target
    }

    /** 资源包：内部存的就是原始安装包，直接复制 */
    private fun exportResourcePack(root: File, outDir: File, type: String, fileName: String): File? {
        val relative = when (type) {
            "TexturePack" -> "module/private/eternal.future.texturepackextension/texture_packs"
            "LanguagePack" -> "module/private/eternal.future.languagepackextension/language_packs"
            "LanguagePatchPack" -> "module/private/eternal.future.languagepackextension/language_patch_packs"
            "FontPack" -> "module/private/eternal.future.fontpackextension/font_packs"
            "AudioPack" -> "module/private/eternal.future.audiopackextension/audio_packs"
            else -> return null
        }
        var src = File(root, "$relative/$fileName")
        if (!src.isFile) return null

        val meta: Pair<String, String>? = runCatching {
            when (type) {
                "TexturePack" -> TexturePackManager.packs.firstOrNull { it.fileName == fileName }
                    ?.let { it.name to it.version }
                "LanguagePack" -> LanguagePackManager.languagePacks.firstOrNull { it.fileName == fileName }
                    ?.let { it.name to it.version }
                "LanguagePatchPack" -> LanguagePatchPackManager.packs.firstOrNull { it.fileName == fileName }
                    ?.let { it.name to it.version }
                "FontPack" -> FontPackManager.fontPacks.firstOrNull { it.fileName == fileName }
                    ?.let { it.name to it.version }
                "AudioPack" -> AudioManager.packs.firstOrNull { it.fileName == fileName }
                    ?.let { it.name to it.version }
                else -> null
            }
        }.getOrNull()

        val displayName = meta?.first.orEmpty()
        val version = meta?.second.orEmpty()

        // 名字和界面上显示的一致；没有元数据就沿用原来的文件名
        val outName = if (displayName.isBlank()) fileName
        else displayFileName(displayName, version, fileName)

        val target = uniqueFile(outDir, outName)
        src.copyTo(target, overwrite = true)
        return target
    }

    /** 内核：把内核目录里的文件重新打成可安装的 zip（info.json + 各平台 .so） */
    private fun exportKernel(outDir: File): File? {
        val dir = File(Platform.getData("tefkernel").toString())
        if (!dir.isDirectory) return null
        val files = dir.listFiles()?.filter { it.isFile && it.length() > 0 } ?: return null
        if (files.isEmpty()) return null

        val version = ConfigurationState.kernelVersion.ifBlank { "unknown" }
        val target = uniqueFile(outDir, safeFileName("TEFKernel_v$version", "TEFKernel") + ".zip")
        ZipOutputStream(FileOutputStream(target)).use { zos ->
            writeText(zos, "info.json", """{"version":"$version"}""")
            files.forEach { f -> writeFile(zos, f, f.name) }
        }
        return target
    }

    // ───────────────────────── 工具 ─────────────────────────

    /**
     * 导出的压缩包名 = 界面上显示的名字（名字 + 版本号）。
     * 例：名字「你已是完全之龙了」+ 版本「10.0.0」→ 你已是完全之龙了v10.0.0.zip
     */
    private fun displayFileName(name: String, version: String, fallback: String): String {
        val n = name.trim().ifBlank { fallback.substringBeforeLast('.').trim() }
        val v = version.trim()
        val tail = when {
            v.isBlank() -> ""
            v.startsWith("v", true) -> v
            else -> "v$v"
        }
        return safeFileName(n + tail, fallback).trimEnd('.', ' ') + ".zip"
    }

    /** 目标目录里重名时自动加 (2)(3)…，避免互相覆盖 */
    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var i = 2
        while (f.exists()) {
            f = File(dir, if (ext.isBlank()) "$base ($i)" else "$base ($i).$ext")
            i++
        }
        return f
    }

    private fun addIcon(zos: ZipOutputStream, root: File, typeDir: String, pkgId: String) {
        val candidates = listOf(
            File(root, "$typeDir/icons/$pkgId.icon"),
            File(root, "$typeDir/icons/$pkgId.png")
        )
        val icon = candidates.firstOrNull { it.isFile } ?: return
        writeFile(zos, icon, "icon.png")
    }

    private fun writeText(zos: ZipOutputStream, entryName: String, text: String) {
        zos.putNextEntry(ZipEntry(entryName))
        zos.write(text.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    private fun writeFile(zos: ZipOutputStream, file: File, entryName: String) {
        zos.putNextEntry(ZipEntry(entryName))
        file.inputStream().use { input -> input.copyTo(zos, 64 * 1024) }
        zos.closeEntry()
    }

    private fun addDirectory(zos: ZipOutputStream, dir: File, prefix: String) {
        val children = dir.listFiles() ?: return
        children.forEach { child ->
            if (child.isDirectory) {
                addDirectory(zos, child, "$prefix${child.name}/")
            } else {
                writeFile(zos, child, "$prefix${child.name}")
            }
        }
    }

    private fun safeFileName(raw: String, fallback: String): String {
        val cleaned = raw.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").trim().trimEnd('.')
        return cleaned.ifBlank { fallback }
    }

    /** 把 SAF 的 tree uri 还原成真实路径 */
    private fun resolveRealPath(uriString: String?): String? {
        if (uriString.isNullOrBlank()) return null
        return try {
            val decoded = URLDecoder.decode(uriString, "UTF-8")
            val marker = "/tree/"
            val idx = decoded.indexOf(marker)
            if (idx < 0) return null
            var docId = decoded.substring(idx + marker.length)
            docId = docId.substringBefore('#').substringBefore('?')
            docId = docId.replace("/document/", "/")
            // primary:Download/xxx  →  /storage/emulated/0/Download/xxx
            when {
                docId.startsWith("primary:") -> {
                    val sub = docId.removePrefix("primary:").trimEnd('/')
                    "/storage/emulated/0/$sub"
                }
                docId.contains(":") -> {
                    // 形如 1A2B-3C4D:some/path
                    val volume = docId.substringBefore(':')
                    val sub = docId.substringAfter(':').trimEnd('/')
                    "/storage/$volume/$sub"
                }
                else -> null
            }
        } catch (e: Throwable) {
            AppLogger.w("resolve target uri failed: ${e.message}")
            null
        }
    }

    /** 通过 SAF 往用户选定的目录里写文件（不需要 root，也不会被分区存储拦） */
    private fun writeIntoSaf(treeUriString: String, src: File): Boolean {
        return try {
            val ctx = MainActivity.context ?: return false
            val treeUri = android.net.Uri.parse(treeUriString)
            val docId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
            val resolver = ctx.contentResolver

            // 同名文件已存在时先删掉，避免 createDocument 生成 "xxx (1).zip"
            try {
                val childrenUri = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(
                    treeUri, docId
                )
                resolver.query(
                    childrenUri,
                    arrayOf(
                        android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME
                    ),
                    null, null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        if (c.getString(1) == src.name) {
                            android.provider.DocumentsContract.deleteDocument(
                                resolver, android.provider.DocumentsContract.buildDocumentUriUsingTree(
                                    treeUri, c.getString(0)
                                )
                            )
                            break
                        }
                    }
                }
            } catch (_: Throwable) {
            }

            val docUri = android.provider.DocumentsContract.createDocument(
                resolver, parent, "application/zip", src.name
            ) ?: return false

            val ok = resolver.openOutputStream(docUri)?.use { out ->
                src.inputStream().use { input -> input.copyTo(out, 64 * 1024) }
                out.flush()
                true
            } ?: false
            ok
        } catch (e: Throwable) {
            AppLogger.w("writeIntoSaf failed: ${src.name}: ${e.message}")
            false
        }
    }

    /** 复制到目标目录：优先 root cp，其次直接写 */
    private fun copyOut(src: File, targetDir: File): Boolean {
        val dest = File(targetDir, src.name)
        if (dest.exists()) dest.delete()
        return try {
            val p = Runtime.getRuntime().exec(
                arrayOf("su", "-c", "cp -f '${src.absolutePath}' '${dest.absolutePath}'")
            )
            val ok = p.waitFor() == 0 && dest.isFile
            if (ok) return true
            src.copyTo(dest, overwrite = true)
            dest.isFile
        } catch (e: Throwable) {
            AppLogger.w("copyOut failed: ${e.message}")
            try {
                src.copyTo(dest, overwrite = true)
                dest.isFile
            } catch (e2: Throwable) {
                false
            }
        }
    }

    private fun timestamp(): String {
        val now = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault())
        fun two(v: Int) = if (v < 10) "0$v" else "$v"
        return "${now.year}${two(now.month.number)}${two(now.day)}_${two(now.hour)}${two(now.minute)}"
    }
}