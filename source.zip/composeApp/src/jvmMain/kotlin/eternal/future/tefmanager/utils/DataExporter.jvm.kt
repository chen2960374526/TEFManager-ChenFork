package eternal.future.tefmanager.utils

/*******************************************************************************
 * TEFManager - DataExporter (Desktop)
 *
 * Copyright (C) 2026 eternalfuture-e38299
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Author: eternalfuture-e38299
 * Modified: 2026/11/19 (新增本文件：数据导出)
 *******************************************************************************/

actual object DataExporter {
    actual fun listEntries(): List<ExportEntry> = emptyList()

    actual fun defaultTargetName(): String = "导出目录"

    actual suspend fun export(
        selectedIds: Set<String>,
        targetUri: String?,
        onProgress: (String) -> Unit
    ): ExportResult? {
        onProgress("桌面端暂不支持该功能")
        return null
    }
}
